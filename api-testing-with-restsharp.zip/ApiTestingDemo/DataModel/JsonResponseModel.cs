﻿namespace ApiTestingDemo.DataModel;

public class JsonResponseModel
{
    public Data data { get; set; }
    public Support support { get; set; }
}
