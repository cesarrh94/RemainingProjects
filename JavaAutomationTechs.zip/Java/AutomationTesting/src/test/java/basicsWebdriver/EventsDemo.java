package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;

public class EventsDemo {

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://text-compare.com/");

        WebElement sourceTextArea = driver.findElement(By.xpath("//form[@id='textCompareForm']//textarea[1]"));
        WebElement targetTextArea = driver.findElement(By.xpath("//form[@id='textCompareForm']//textarea[2]"));


        Actions action = new Actions(driver);

        // command - copy action
        sourceTextArea.clear();
        sourceTextArea.sendKeys("cesar");
        action.keyDown(sourceTextArea, Keys.COMMAND).sendKeys("a").sendKeys("c").build().perform();

        Thread.sleep(3000);

        // command - paste action
        targetTextArea.clear();
        action.keyDown(targetTextArea, Keys.BACK_SPACE).build().perform();
        action.keyDown(targetTextArea, Keys.COMMAND).sendKeys("v").build().perform();

        Thread.sleep(3000);

        driver.quit();

    }

}
