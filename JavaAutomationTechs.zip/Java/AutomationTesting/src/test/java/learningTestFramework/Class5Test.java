package learningTestFramework;


import org.testng.SkipException;
import org.testng.annotations.Test;

public class Class5Test {

    /* Different ways to skip a @Test */

    @Test(enabled = false)
    public void skipTestOne() {
        System.out.println("Test 1 - Not Executed...");

    }

    @Test
    public void skipTestTwo() {
        System.out.println("Test 2 - Not Executed...");
    }

    boolean flag = false;

    @Test
    public void skipTestThree() {
        if (flag) {
            System.out.println("Test 3 - Executed...");
        } else {
            throw new SkipException("Test 3 - Not Executed...");
        }
    }


}
