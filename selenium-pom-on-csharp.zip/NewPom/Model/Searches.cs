namespace NewPom.Model
{
    public class Searches
    {
        public string searchOne { get; set; }
        public string searchTwo { get; set; }
        public string searchThree { get; set; }
        public string searchFour { get; set; }
        public string searchFive { get; set; }
    }
}