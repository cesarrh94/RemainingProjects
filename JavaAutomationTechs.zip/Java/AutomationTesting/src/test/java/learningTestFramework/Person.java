package learningTestFramework;

public class Person {

    private String name;
    private int age;
    private String genderIdentity;

    public Person(String name, int age, String genderIdentity) {
        this.name = name;
        this.age = age;
        this.genderIdentity = genderIdentity;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGenderIdentity() {
        return genderIdentity;
    }
}
