package collections;

import java.util.Stack;

public class StackDemo {

    public static void main(String[] args) {

        // creation of a stack
        Stack<String> animals = new Stack<>();

        // adding elements to the stack
        animals.push("dog");
        animals.push("cat");
        animals.push("parrot");
        animals.push("rabbit");
        animals.push("hamster");


        System.out.println("animal stack: " + animals);

        // removing an element from the stack
        String elementPopped = animals.pop();
        System.out.println("element removed from animal stack: " + elementPopped);

        // returning the top element/object in the stack
        String topElement = animals.peek();
        System.out.println("top element in stack: " + topElement);

        // search the element by value and returns the position of that element
        // on the stack, NOT Index!
        int indexElement = animals.search("rabbit");
        System.out.println("index of (cat) element on stack: " + indexElement);

    }

}
