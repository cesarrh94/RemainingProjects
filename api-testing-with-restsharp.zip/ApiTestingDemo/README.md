# ApiTestingDemo
This repository is only to store my learning process on the API Automation Testing with RestSharp and C#
