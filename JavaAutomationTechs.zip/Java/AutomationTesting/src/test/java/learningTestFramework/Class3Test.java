package learningTestFramework;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import static org.testng.Assert.assertEquals;

/* In this class we are going to review the Hard and Soft Assertions*/
public class Class3Test {

    Person myPerson = new Person("cesar", 29, "male");

    /* Difference between HARD vs SOFT assertions:
    *
    * Hard Assert: throws an AssertException immediately when an assert statement fails
    * and test suite continues with next @Test, The disadvantage of Hard Assert –
    * It marks method as fail if assert condition gets failed and the remaining
    * statements inside the method will be aborted.
    *
    * Soft Assert – Soft Assert collects errors during @Test,
    * Soft Assert does not throw an exception when an assert fails and
    * would continue with the next step after the assert statement.
    * */

    @Test
    public void validatePersonObject_hardAssertTest() {
        String expectedName = "cesar";
        int expectedAge = 29;
        String expectedGenderIdentity = "male";

        System.out.println("Validating Person's Name");
        assertEquals(myPerson.getName(), expectedName);
        System.out.println("Validating Person's Age");
        assertEquals(myPerson.getAge(), expectedAge);
        System.out.println("Validating Person's Gender Identity");
        assertEquals(myPerson.getGenderIdentity(), expectedGenderIdentity);
    }

    @Test
    public void validatePersonObject_softAssertTest() {

        SoftAssert sa = new SoftAssert();

        String expectedName = "cesar";
        int expectedAge = 28;
        String expectedGenderIdentity = "male";

        System.out.println("Validating Person's Name - SA");
        sa.assertEquals(myPerson.getName(), expectedName);
        System.out.println("Validating Person's Age - SA");
        sa.assertEquals(myPerson.getAge(), expectedAge);
        System.out.println("Validating Person's Gender Identity - SA");
        sa.assertEquals(myPerson.getGenderIdentity(), expectedGenderIdentity);
        sa.assertAll();
    }

}
