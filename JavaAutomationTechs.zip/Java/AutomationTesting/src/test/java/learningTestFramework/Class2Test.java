package learningTestFramework;

/* In this lesson we are going to work with BeforeTest/AfterTest & BeforeMethod/AfterMethod annotation */

import org.testng.annotations.*;

public class Class2Test {

    /* the @BeforeTest/@AfterTest will be executed once no matter how many @Test are in the Class.*/
    /* the @BeforeMethod/@AfterMethod will be executed before and after each @Test like an opening and closing closure! */

    @BeforeTest
    public void beforeTest() {
        System.out.println("@BeforeTest active ***");
    }

    @BeforeMethod
    public void beforeMethod() {
        System.out.println("@BeforeMethod active >>>");
    }

    @Test
    public void myOneTest() {
        System.out.println("Hello from @Test: 1");
    }

    @Test
    public void mySecondTest() {
        System.out.println("Hello form @Test: 2");
    }

    @AfterMethod
    public void afterMethod() {
        System.out.println("@AfterMethod active <<<");
    }

    @AfterTest
    public void afterTest() {
        System.out.println("@AfterTest active ***");
    }
}
