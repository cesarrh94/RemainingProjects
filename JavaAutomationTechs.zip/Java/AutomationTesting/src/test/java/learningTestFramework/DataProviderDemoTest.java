package learningTestFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.Duration;

/* In this class, we are going to review the DataProvider annotation: is a way to pass parameters in the test function.
* The DataProvider works similar has a table where we have rows a columns*/

public class DataProviderDemoTest {

    @Test(priority = 1, dataProvider = "dataSet", dataProviderClass = Providers.class)
    public void loginTest(String username, String password) {
        System.out.println(username + " " + password);
    }


    @Test(priority = 2, dataProvider = "createUser", dataProviderClass = Providers.class)
    public void loginSauceDemoTest(String username, String password) {
        WebDriver driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://www.saucedemo.com/");

        driver.findElement(By.id("user-name")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("login-button")).click();

        System.out.println("test completed");

        driver.quit();
    }
}
