package dsa;

public class QueueDemo {

    public static void main(String[] args) {

    }
}
