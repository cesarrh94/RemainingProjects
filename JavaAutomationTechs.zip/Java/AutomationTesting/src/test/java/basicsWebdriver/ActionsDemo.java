package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsDemo {

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.ebay.com/?_ul=MX");

        WebElement modaLink = driver.findElement(By.linkText("Moda"));

        // Perform a Mouse hover to the link
        Actions actions = new Actions(driver);
        actions.moveToElement(modaLink).perform();

        Thread.sleep(5000);

        driver.quit();

    }

}
