package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.time.Duration;

public class LoginSuccessfulSteps {

    WebDriver driver;
    String URL = "https://www.saucedemo.com/";
    String username = "standard_user";
    String password = "secret_sauce";

    @Given("I am on the login page of SauceLabs")
    public void i_am_on_the_login_page_of_sauce_labs() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get(URL);
    }
    @When("I login with a valid username and password")
    public void i_login_with_a_valid_username_and_password() {
        driver.findElement(By.id("user-name")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.xpath("//input[@type='submit']")).click();
    }
    @Then("I should see home page")
    public void i_should_see_home_page() {
        String titlePageSection = driver.findElement(By.xpath("//span[text()='Products']")).getText();
        Assert.assertEquals(titlePageSection, "Products");
    }

    @After
    public void tearDown() {
        driver.quit();
    }


}
