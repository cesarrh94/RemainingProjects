package dsa;

public class ArraysDemo {

    public static void main(String[] args) {

        // declare and allocate memory for an array
        String[] footballPlayers = new String[5];

        // initialize array
        footballPlayers[0] = "messi";
        footballPlayers[1] = "ronaldo";
        footballPlayers[2] = "pele";
        footballPlayers[3] = "maradona";
        footballPlayers[4] = "zidane";

        // access to the elements of the array
        System.out.println("first element: " + footballPlayers[0]);
        System.out.println("last element: " +
                footballPlayers[footballPlayers.length -1]);

        System.out.println("array length (elements): " +
                footballPlayers.length);

        // loop through the array
        for (int i = 0; i < footballPlayers.length; i++) {
            System.out.println("top " + (i + 1) + ": " +
                    footballPlayers[i].toUpperCase());
        }

        // change value of an element
        footballPlayers[4] = "cruyff";
        System.out.println("updated element: " + footballPlayers[footballPlayers.length - 1]);



    }
}
