package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.List;

import static java.lang.Thread.sleep;

public class PrintAllLinks {

    public static String url = "https://the-internet.herokuapp.com";

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get(url);

        List<WebElement> links = driver.findElements(By.tagName("a"));
        System.out.println("list size: " + links.size());

        for (WebElement link : links) {
            System.out.println("index: " + links.indexOf(link) + " - " + link.getText());
            System.out.println("link: " + link.getAttribute("href"));
        }

        sleep(3000);

        links.get(1).click();
        sleep(2000);

        System.out.println("\npage title header: " + driver.findElement(By.tagName("h3")).getText());

        driver.quit();

    }
}
