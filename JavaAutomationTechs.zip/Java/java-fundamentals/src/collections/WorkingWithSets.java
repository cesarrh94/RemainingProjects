package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class WorkingWithSets {

    public static void main(String[] args) {

        // creating a hashset
        Set<String> animals = new HashSet<>();

        // adding elements to the hashset
        animals.add("dog");
        animals.add("cat");
        animals.add("parrot");

        System.out.println("set: " + animals);

        // access elements in the set - using an iterator
        Iterator<String> iterator = animals.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // looping through a forEach
        for (String item : animals) {
            System.out.println(item.toUpperCase());
        }

        // remove elements
        boolean removedElement = animals.remove("parrot");
        System.out.println("element was removed? " + removedElement);

        // size of the set
        System.out.println("size: " + animals.size());

    }
}
