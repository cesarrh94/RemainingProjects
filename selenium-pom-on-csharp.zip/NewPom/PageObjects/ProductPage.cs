using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace NewPom.PageObjects
{
    public class ProductPage
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        private By priceFromBuyButton = By.CssSelector(".Price-module__boldText___vmNHu.Price-module__moreText___q5KoT.AcquisitionButtons-module__listedPrice___PS6Zm");
        private By addToCartButton = By.XPath("//button[@title='Add Forza Motorsport Premium Edition to cart']");
        private By goToCartButton = By.XPath("//a[@id='uhf-shopping-cart']");
        public ProductPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(this.driver, TimeSpan.FromSeconds(10));
        }

        public string getPriceFromBuyButton()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(priceFromBuyButton));
            return driver.FindElement(priceFromBuyButton).Text;
        }

        public void clickOnAddToCart()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(addToCartButton));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(addToCartButton));
            driver.FindElement(addToCartButton).Click();
        }

        public void goToCart()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(goToCartButton));
            driver.FindElement(goToCartButton).Click();
        }

    }
}