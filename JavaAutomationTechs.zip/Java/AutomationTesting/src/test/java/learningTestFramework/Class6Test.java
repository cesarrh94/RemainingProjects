package learningTestFramework;

import org.testng.annotations.*;

/* In this lesson we are going to review the annotations: */
public class Class6Test {

    /* @BeforeClass method will be run before the first test method in the current class invoked,
    @AfterClass method will be run after all test methods in the current class have been run.

    This is quite useful to set up a test that required a specific data set before or after to be executed*/

    /* @BeforeGroups and @AfterGroups will be executed before and after to the specified group value.*/

    @BeforeClass
    public void beforeClass(){
        System.out.println("Shout out from @BeforeClass");
    }

    @BeforeGroups(value = "software")
    public void beforeGroups() {
        System.out.println("Here from @BeforeGroups -->");
        System.out.println("Opening Software...");
    }

    @Test(groups = "hardware")
    public void pcOne(){
        System.out.println("Hello from PC One");
    }

    @Test(groups = "hardware")
    public void pcTwo(){
        System.out.println("Hello from PC Two");
    }

    @Test(groups = "hardware")
    public void pcThree(){
        System.out.println("Hello from PC Three");
    }

    @Test(groups = "software")
    public void startAdobePS(){
        System.out.println("Starting Adobe Photoshop");
    }

    @Test(groups = "software")
    public void startMicrosoftExcel(){
        System.out.println("Starting Microsoft Excel");
    }
    @Test(groups = "software")
    public void startObsStudio(){
        System.out.println("Starting OBS Studio");
    }

    @AfterGroups(value = "software")
    public void afterGroups() {
        System.out.println("Here from @AfterGroups <--");
        System.out.println("Closing Software...");
    }

    @AfterClass
    public void afterClass(){
        System.out.println("Shout out from @AfterClass");
    }

}
