package dsa;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {

    public static void main(String[] args) {

        // create a list
        List<Integer> messiGoldenBalloon = new ArrayList<>();

        // add elements to the list
        messiGoldenBalloon.add(2009);
        messiGoldenBalloon.add(2010);
        messiGoldenBalloon.add(2011);
        messiGoldenBalloon.add(2012);
        messiGoldenBalloon.add(2015);
        messiGoldenBalloon.add(2019);
        messiGoldenBalloon.add(2021);
        messiGoldenBalloon.add(2023);

        // print the representation of the list
        System.out.println(messiGoldenBalloon);

        // length of the list
        System.out.println("list length: " + messiGoldenBalloon.size());

        // access elements of the list
        System.out.println("access first element: " + messiGoldenBalloon.get(0));
        System.out.println("access last element: " + messiGoldenBalloon.get(messiGoldenBalloon.size() -1));

        // change value of an element
        messiGoldenBalloon.set(6, 2020);
        System.out.println("updated list " + messiGoldenBalloon);

        // remove element from list
        int elementRemoved = messiGoldenBalloon.remove(7);
        System.out.println("element removed: " + elementRemoved);
        System.out.println("updated list: " + messiGoldenBalloon);

        // loop through the list
        System.out.println("looping through the list:");
        for (int winningYear : messiGoldenBalloon) {
            System.out.println(winningYear);
        }


    }
}
