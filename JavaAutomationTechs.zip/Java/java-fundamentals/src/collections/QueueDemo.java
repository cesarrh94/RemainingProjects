package collections;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo {

    public static void main(String[] args) {

        // creating a queue using the linked list class
        Queue<Integer> numbers = new LinkedList<>();

        // adding elements to the queue-linkedList
        numbers.offer(1);
        numbers.offer(2);
        numbers.offer(3);
        numbers.offer(4);
        numbers.offer(5);

        System.out.println("Queue: " + numbers);

        // also adding elements to the queue but using add method.
        numbers.add(6);
        numbers.add(7);
        numbers.add(8);
        numbers.add(9);
        numbers.add(10);

        System.out.println("Queue: " + numbers);

        // accessing the first element on queue (front element)
        int headElement = numbers.element();
        System.out.println("element() " + headElement);

        headElement = numbers.peek();
        System.out.println("peek() " + headElement);

        // removing the first element on queue (front element)
        int removedElement = numbers.remove();
        System.out.println("remove() " + removedElement);

        removedElement = numbers.poll();
        System.out.println("poll() " + removedElement);

        System.out.println(numbers);



        /* Priority Queue */
        PriorityQueue<Integer> newNumbers = new PriorityQueue<>();

        newNumbers.offer(4);
        newNumbers.offer(2);
        newNumbers.offer(9);
        newNumbers.offer(6);
        newNumbers.offer(8);
        newNumbers.offer(7);

        System.out.println("PriorityQueue: " + newNumbers);

        newNumbers.offer(1);
        System.out.println("Updated PriorityQueue: " + newNumbers);

        int firstNewElement = newNumbers.peek();
        System.out.println("first element: " + firstNewElement);






    }

}
