package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.List;

import static java.lang.Thread.sleep;

public class HandleCheckboxAndRadio {
    public static String url = "http://test.rubywatir.com/checkboxes.php";

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get(url);

        /* There are 2 ways to handle checkboxes and radio buttons:
        * 1 - create a single element for each item
        * 2 - create a list to store all the items*/

        WebElement cbSoccer = driver.findElement(By.xpath("//input[@value='soccer']"));
        WebElement cbFootball = driver.findElement(By.xpath("//input[@value='football']"));
        WebElement cbBaseball = driver.findElement(By.xpath("//input[@value='baseball']"));
        WebElement cbBasketball = driver.findElement(By.xpath("//input[@value='basketball']"));
        WebElement cbSnooker = driver.findElement(By.xpath("//input[@value='snooker']"));
        WebElement cbRugby = driver.findElement(By.xpath("//input[@value='rugby']"));
        WebElement cbGolf = driver.findElement(By.xpath("//input[@value='golf']"));
        WebElement cbNetball = driver.findElement(By.xpath("//input[@value='netball']"));

        sleep(2000);

        List<WebElement> sports = driver.findElements(By.tagName("input"));

        // logic to deselect the default options
        for (WebElement sport : sports) {
            if (sport.isSelected()) {
                sport.click();
                sleep(2000);
            }
        }

        cbSoccer.click();
        cbBasketball.click();

        sleep(2000);

        driver.quit();

    }

}
