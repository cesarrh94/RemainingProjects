package collections;


import java.util.HashMap;
import java.util.Map;

public class MapDemo {

    public static void main(String[] args) {

        // the map (hashmap) is used to store unique pairs (key/value) data!

        // create a hashmap
        HashMap<Integer, String> students = new HashMap<>();

        // add elements to hashmap
        students.put(1, "rafael");
        students.put(2, "rosalba");
        students.put(3, "cesar");
        students.put(4, "jennifer");
        students.put(5, "marcos");

        System.out.println("hashmap representation: " + students);

        // the hashmap has the ability to performed CRUD operations!
        // 1. create or add element to map
        students.put(6, "benji");

        // 2. read or get element (value) by using key
        System.out.println("value: " + students.get(6));

        System.out.println("students keys: " + students.keySet());
        System.out.println("students values: " + students.values());
        System.out.println(students.entrySet());

        // 3. update/replace element in the map
        System.out.println("original hashmap: " + students);
        students.replace(6, "vaquita");
        System.out.println("modified hashmap: " + students);

        // 4. remove/delete element in the map
        String elementRemoved = students.remove(6);
        System.out.println("element removed: " + elementRemoved);


        // loop through a hashmap
        for (Map.Entry<Integer, String> student : students.entrySet()) {
            System.out.println(student);
        }

        for (int key : students.keySet()) {
            System.out.println(key);
        }

        for (String value : students.values()) {
            System.out.println(value);
        }

    }
}
