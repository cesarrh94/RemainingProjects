package learningTestFramework;

import org.testng.annotations.DataProvider;

public class Providers {

    @DataProvider
    public Object[][] dataSet() {

        // thinks this as a table (rows and columns)
        Object[][] dataSet = new Object[4][2];

        // table entries
        dataSet[0][0] = "user1";
        dataSet[0][1] = "password1";

        dataSet[1][0] = "user2";
        dataSet[1][1] = "password2";

        dataSet[2][0] = "user3";
        dataSet[2][1] = "password3";

        dataSet[3][0] = "user4";
        dataSet[3][1] = "password4";

        return dataSet;
    }

    @DataProvider(name = "createUser")
    public Object[][] dataSet2() {
        return new Object[][] {
                {"standard_user", "secret_sauce"},
                {"locked_out_user", "secret_sauce"},
                {"problem_user", "secret_sauce"},
                {"performance_glitch_user", "secret_sauce"},
                {"error_user", "secret_sauce"},
                {"visual_user", "secret_sauce"},
        };
    }

}
