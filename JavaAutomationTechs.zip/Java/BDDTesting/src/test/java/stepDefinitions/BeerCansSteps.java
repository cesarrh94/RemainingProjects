package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BeerCansSteps {

    private int beerCans = 0;

    @Given("I have {int} beer cans")
    public void i_have_beer_cans(int int1) {
        // Write code here that turns the phrase above into concrete actions
        // throw new io.cucumber.java.PendingException();
        beerCans = int1;
        System.out.println("opening balance: " + beerCans);
    }

    @Given("I have drunk {int} beer cans")
    public void i_have_drunk_beer_cans(int int1) {
        // Write code here that turns the phrase above into concrete actions
        // throw new io.cucumber.java.PendingException();
        beerCans = beerCans - int1;
        System.out.println("processed " + beerCans);
    }

    @When("I go to my fridge")
    public void i_go_to_my_fridge() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
        System.out.println("going to fridge");
    }

    @Then("I should have {int} beer cans")
    public void i_should_have_beer_cans(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
        System.out.println("in stock: " + beerCans);
        System.out.println("--- --- --- ---");
    }
}
