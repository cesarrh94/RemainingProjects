package learningTestFramework;

import org.testng.annotations.Test;

/* The test class should be named according to the feature/functionality
* that is going to be tested!
* e.g. LoginTest, PurchaseTest, SignupTest, etc.*/
public class Class1Test {

    @Test (priority = 1)
    public void secondTest() {
        /* The annotation @Test indicates this method is a test.
        * Note: testng executes the test alphabetically.*/
        System.out.println("Hello from secondTest()");
    }

    @Test (priority = 2)
    /* The priority attribute indicates the execution order on the test
    * framework of testng.*/
    public void firstTest() {
        System.out.println("Hello from firstTest()");
    }
}
