package collections;

public class MultidimensionalArray {

    public static void main(String[] args) {

        // a multidimensional array is an array of arrays.

        // declaration and allocation on memory for the array
        int[][] newSeats = new int[3][5];

        // initializing the array;
        newSeats[0][0] = 11;
        newSeats[0][1] = 12;
        newSeats[0][2] = 13;
        newSeats[0][3] = 14;
        newSeats[0][4] = 15;

        newSeats[1][0] = 21;
        newSeats[1][1] = 22;
        newSeats[1][2] = 23;
        newSeats[1][3] = 24;
        newSeats[1][4] = 25;

        newSeats[2][0] = 31;
        newSeats[2][1] = 32;
        newSeats[2][2] = 33;
        newSeats[2][3] = 34;
        newSeats[2][4] = 35;

        // declaration of an array;
        int[][] seats;

        // initialization of the array
        seats = new int[][] {
                {1, 2, 3, 4, 5},
                {5, 4, 3, 2, 1,},
                {1, 4, 3, 2, 5}
        };

        System.out.println("newSeats array:");
        for (int i = 0; i < newSeats.length; i++) {
            for (int j = 0; j < newSeats[i].length; j++) {
                System.out.print(newSeats[i][j] + ",");
            }
            System.out.println();
        }

        System.out.println("\nseats array:");
        for (int i = 0; i < seats.length; i++) {
            for (int j = 0; j < seats[i].length; j++) {
                System.out.print(seats[i][j] + ",");
            }
            System.out.println();
        }

    }
}
