using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace NewPom.PageObjects
{
    public class CartPage
    {
        private IWebDriver driver;
        private WebDriverWait wait;

        private By priceFromCart = By.XPath("//span[@itemprop='price']");
        public CartPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(this.driver, TimeSpan.FromSeconds(10));
        }

        public string getPriceFromCart()
        {
            return driver.FindElement(priceFromCart).Text;
        }

    }
}