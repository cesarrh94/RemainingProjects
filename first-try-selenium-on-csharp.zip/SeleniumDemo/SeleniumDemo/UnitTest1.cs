using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;

namespace SeleniumDemo;

public class Tests
{

    WebDriver driver;
    string url = "https://www.microsoft.com/en-us";

    [SetUp]
    public void Setup()
    {
        // new DriverManager().SetUpDriver(new ChromeConfig());

        // ChromeOptions options = new ChromeOptions();
        // options.AddArgument("--incognito");
        // driver = new ChromeDriver(options);
        driver = new ChromeDriver();

        driver.Manage().Window.Maximize();
        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
    }

    [Test]
    public void TestMicrosoftSearch()
    {
        // 1. Navigate to Microsoft
        driver.Navigate().GoToUrl(url);

        // 2. Validate "Microsoft" is on page title
        string pageTitle = driver.Title;
        Assert.IsTrue(pageTitle.Contains("Microsoft"));

        // 3. Validate Header elements existed
        List<IWebElement> headerLinks = driver.FindElements(By.XPath("//nav[@id='uhf-g-nav']/ul/li[@class='single-link js-nav-menu uhf-menu-item']")).ToList();

        foreach (IWebElement link in headerLinks)
        {
            Console.WriteLine();
            Assert.IsTrue(link.Displayed);
        }

        // 4. Search "xbox" 
        IWebElement searchButton = driver.FindElement(By.Id("search"));
        searchButton.Click();

        IWebElement searchInput = driver.FindElement(By.Id("cli_shellHeaderSearchInput"));
        searchInput.SendKeys("xbox");

        Thread.Sleep(2000);

        // 5. Select first link in the list result
        List<IWebElement> searchResults = driver.FindElements(By.XPath("//*[@class='f-product']")).ToList();
        foreach (IWebElement sr in searchResults)
        {
            Console.WriteLine("link: " + searchResults.IndexOf(sr) + " - " + sr.Text);
        }
        searchResults[0].Click();

        Thread.Sleep(3000);

        // 6. Close pop-up window
        IWebElement signUpWindowCloseButton = driver.FindElement(By.XPath("//button[@aria-label='Close dialog window']"));
        signUpWindowCloseButton.Click();
        // IWebElement regionWindowCloseButton = driver.FindElement(By.XPath("//button[@aria-label='Cancel']"));
        // regionWindowCloseButton.Click();

        Thread.Sleep(2000);
    }

    [TearDown]
    public void TearDown()
    {
        driver.Quit();
    }
}