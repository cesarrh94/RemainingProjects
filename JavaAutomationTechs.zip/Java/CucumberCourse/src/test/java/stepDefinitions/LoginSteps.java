package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        System.out.println("User is on Login Page");
    }
    @When("I enter my {string} and password {string}")
    public void i_enter_my_and_password(String username, String password) {
        System.out.println("User is typing credentials...");
        System.out.println("username: " + username);
        System.out.println("password: " + password);
    }
    @When("Click the login button")
    public void click_the_login_button() {
        System.out.println("Click on login button");
    }
    @Then("I should see the home page")
    public void i_should_see_the_home_page() {
        System.out.println("Welcome to Homepage");
    }

}
