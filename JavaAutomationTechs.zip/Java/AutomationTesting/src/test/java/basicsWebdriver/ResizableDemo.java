package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.time.Duration;

public class ResizableDemo {

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://jqueryui.com/resizable/");

        WebElement iframe = driver.findElement(By.className("demo-frame"));
        driver.switchTo().frame(iframe);

        Thread.sleep(2000);

        WebElement resizableHandle = driver.findElement(By.cssSelector("div.ui-resizable-handle:nth-child(4)"));
        Actions action = new Actions(driver);

        // 1 - using dragAndDropBy method
        action.dragAndDropBy(resizableHandle, 150, 100).build().perform();
        System.out.println("dragAndDropBy");

        Thread.sleep(3000);

        // 2 - using clickAndHold method
        new Actions(driver).clickAndHold(resizableHandle).moveByOffset(250, 175).build().perform();
        System.out.println("clickAndHold");
        Thread.sleep(3000);


        System.out.println("resizable successful...");


        driver.quit();


    }
}
