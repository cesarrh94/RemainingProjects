package dsa;

import java.util.Stack;

public class StackDemo {

    public static void main(String[] args) {

        // create a stack
        Stack<String> books = new Stack<>();

        // add elements to stack
        books.push("a tale of two cities");
        books.push("the little prince");
        books.push("the bible");
        books.push("the hobbit");
        books.push("the da vinci code");

        // print the representation of the stack
        System.out.println("stack: " + books);

        // remove element from the top of the stack
        String elementRemoved = books.pop();
        System.out.println("element removed: " + elementRemoved);

        // returns element from the top of the stack
        String elementSelected = books.peek();
        System.out.println("element at top: " + elementSelected);

        // search an element in the stack. it returns the position (index)
        // of the element from the top of the stack.
        int position = books.search("the bible");
        System.out.println("position of 'the bible': " + position);

    }
}
