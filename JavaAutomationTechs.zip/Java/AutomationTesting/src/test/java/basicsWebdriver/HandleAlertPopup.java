package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

import static java.lang.Thread.sleep;
import static org.testng.Assert.*;


public class HandleAlertPopup {

    public static String url = "https://the-internet.herokuapp.com/javascript_alerts";
    WebDriver driver;

    WebElement alert;
    WebElement confirmAlert;
    WebElement promptAlert;
    WebElement confirmationMessage;

    @BeforeTest
    public void setup() {
        System.out.println("setup method");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get(url);

        alert = driver.findElement(By.xpath("//button[@onclick='jsAlert()']"));
        confirmAlert = driver.findElement(By.xpath("//button[@onclick='jsConfirm()']"));
        promptAlert = driver.findElement(By.xpath("//button[@onclick='jsPrompt()']"));
        confirmationMessage = driver.findElement(By.xpath("//p[@id='result']"));

    }

    @Test
    public void acceptAlertTest() throws InterruptedException {
        alert.click();
        sleep(2000);
        driver.switchTo().alert().accept();
        driver.switchTo().parentFrame();
        assertTrue(confirmationMessage.isDisplayed());
        assertEquals(confirmationMessage.getText(), "You successfully clicked an alert");
    }

    @Test
    public void dismissOnConfirmationAlertTest() throws InterruptedException {
        confirmAlert.click();
        sleep(2000);
        driver.switchTo().alert().dismiss();
        driver.switchTo().parentFrame();
        assertTrue(confirmationMessage.isDisplayed());
        assertEquals(confirmationMessage.getText(), "You clicked: Cancel");
    }

    @Test
    public void promptAlertTest() throws InterruptedException {
        promptAlert.click();
        sleep(2000);
        String name = "cesar";
        driver.switchTo().alert().sendKeys(name);
        driver.switchTo().alert().accept();
        driver.switchTo().parentFrame();
        assertTrue(confirmationMessage.isDisplayed());
        assertEquals(confirmationMessage.getText(), "You entered: cesar");
    }

    @AfterTest
    public void tearDown() {
        System.out.println("tearDown method");
        driver.quit();
    }
}
