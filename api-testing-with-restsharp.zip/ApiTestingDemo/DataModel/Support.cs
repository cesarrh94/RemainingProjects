﻿namespace ApiTestingDemo.DataModel;

public class Support
{
    public string url { get; set; }
    public string text { get; set; }
}
