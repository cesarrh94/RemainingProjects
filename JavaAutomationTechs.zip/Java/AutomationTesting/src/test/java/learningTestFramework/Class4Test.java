package learningTestFramework;

import org.testng.SkipException;
import org.testng.annotations.Test;

/* In this class we are going to review categorization on groups and test suites. */
public class Class4Test {

    /* the @group annotation only represent the list of groups in this class
    * the test method belongs to.*/

    /* A Test Suite is a collection of test that in TestNG is considered a test files or test classes. */

    @Test (groups = "login_page")
    public void successfulLoginTest() {
        System.out.println("Successful Login");
    }

    @Test (groups = {"login_page", "failed_login"})
    public void incorrectUserNameTest() {
        System.out.println("UserName is invalid");
    }

    @Test (groups = {"login_page", "failed_login"})
    public void incorrectPasswordTest() {
        System.out.println("Password is invalid");
    }

    @Test (groups = "purchase_page")
    public void iphonePurchaseTest() {
        System.out.println("iPhone has been purchased");
    }

    @Test (groups = "purchase_page")
    public void samsungPurchaseTest() {
        System.out.println("Samsung phone has been purchased");
    }

}
