package basicsWebdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;

public class BasicMethods {

    public static String browser = "chrome";
    public static WebDriver driver;
    public static String url = "https://www.google.com.mx/";

    public static void main(String[] args) throws InterruptedException {

        if (browser.equalsIgnoreCase("chrome")) {
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            driver = new EdgeDriver();
        }

        driver.get(url);

        String currentUrl = driver.getCurrentUrl();
        System.out.println("current url: " + currentUrl);

        String pagetitle = driver.getTitle();
        System.out.println("page title: " + pagetitle);
        Thread.sleep(3000);

        // navigate to saucedemo page
        url = "https://www.saucedemo.com/";
        driver.navigate().to(url);

        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // get all the elements
        List<WebElement> products = driver.findElements(By.xpath("//div[@class='inventory_item']"));
        Thread.sleep(3000);


        driver.quit();

    }

}
